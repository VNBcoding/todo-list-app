<?php

// Database connection parameters
$sName = "localhost"; // Server name or IP address
$uName = "root";      // MySQL username
$pass = "";           // MySQL password (if any)
$db_name = "todolist"; // Name of the MySQL database

try {
    // Attempting to establish a connection to the MySQL database using PDO
    $conn = new PDO("mysql:host=$sName;dbname=$db_name", $uName, $pass);
    
    // Setting PDO to throw exceptions on errors
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (PDOException $e) {
    // Handling connection errors by catching PDO exceptions
    echo "Connection failed: " . $e->getMessage(); // Outputting error message
}

?>
