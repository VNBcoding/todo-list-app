<?php
if(isset($_POST['email']) && isset($_POST['password'])){
    require '../db_conn.php';

    // Retrieve the email and password from the form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate email and password (e.g., check for empty fields, validate email format, etc.)

    // Hash the password using bcrypt
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Begin a transaction
        $conn->beginTransaction();

       // Insert user data into the users table
    $stmt = $conn->prepare("INSERT INTO users (email, password_hash, password) VALUES (?, ?, ?)");
    $res = $stmt->execute([$email, $hashedPassword, $password]);


        if($res){
            // Retrieve the ID of the newly inserted user
            $userId = $conn->lastInsertId();
            // Commit the transaction
            $conn->commit();

            // Redirect to the login page upon successful signup
            header("Location: ../login.php");
            exit();
        } else {
            // Rollback the transaction if the signup fails
            $conn->rollback();

            // Redirect back to the signup page with an error message
            header("Location: ../signup.php?mess=error");
            exit();
        }
    } catch (PDOException $e) {
        // Rollback the transaction and display an error message
        $conn->rollback();
        echo "Error: " . $e->getMessage();
        exit();
    } finally {
        // Close the database connection
        $conn = null;
    }
} else {
    // Redirect back to the signup page with an error message if the form data is incomplete
    header("Location: ../signup.php?mess=error");
    exit();
}
?>