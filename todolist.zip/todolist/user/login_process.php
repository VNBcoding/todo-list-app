<?php
session_start(); // Start session if not already started

if(isset($_POST['email']) && isset($_POST['password'])){
    require '../db_conn.php'; // Include database connection script

    // Retrieve email and password from the form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate email and password (e.g., check for empty fields)

    try {
        // Query to check if the user exists in the database
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(); // Fetch user data from the database

        // Verify if the user exists and the password is correct
        if($user && password_verify($password, $user['password_hash'])){
            // Authentication successful
            $_SESSION['user_id'] = $user['id']; // Store user ID in session
            header("Location: ../index.php"); // Redirect to the dashboard or home page
            exit();
        } else {
            // Invalid credentials
            header("Location: ../login.php?error=invalid_credentials"); // Redirect to login page with error message
            exit();
        }
    } catch (PDOException $e) {
        // Error handling
        echo "Error: " . $e->getMessage();
        exit();
    } finally {
        // Close the database connection
        $conn = null;
    }
} else {
    // Redirect to the login page if email and password are not set
    header("Location: ../login.php"); 
    echo "hello";
    exit();
}
?>
