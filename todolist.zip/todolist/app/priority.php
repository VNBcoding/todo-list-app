<?php
if(isset($_POST['id'])){
    require '../db_conn.php';

    $id = $_POST['id'];

    if(empty($id)){
       echo 'error';
    } else {
        $todo = $conn->prepare("SELECT id, priority1 FROM todo WHERE id=?");
        $todo->execute([$id]);

        $row = $todo->fetch();
        $uId = $row['id'];
        $priority = $row['priority1']; 

        // Toggle the priority status
        $uPriority = $priority ? 0 : 1;

        // Use prepared statement for the UPDATE query
        $stmt = $conn->prepare("UPDATE todo SET priority1=? WHERE id=?");
        $res = $stmt->execute([$uPriority, $uId]);

        if($res){
            echo $priority; // Return the original priority status
        } else {
            echo "error";
        }
        $conn = null;
        exit();
    }
} else {
    header("Location: ../index.php?mess=error");
}
?>
