<?php
session_start();

// Check if the form has been submitted and user is logged in
if(isset($_POST['title']) && isset($_POST['date_time']) && isset($_SESSION['user_id'])){
    // Include the database connection script
    require '../db_conn.php';

    // Retrieve the title and date from the form data
    $title = $_POST['title'];
    $date_time = $_POST['date_time'];
    $user_id = $_SESSION['user_id']; // Retrieve user_id from session

    // Check if the title field is empty
    if(empty($title) || empty($date_time)){
        // If the title field is empty, redirect back to the index.php page with an error message
        header("Location: ../index.php?mess=error1");
        exit(); // Make sure to exit after the redirection
    }
    else{
        // Prepare and execute SQL statement to insert task into todo table
        $stmt = $conn->prepare("INSERT INTO todo (title, date_time, user_id) VALUES (?, ?, ?)");
        $res = $stmt->execute([$title, $date_time, $user_id]);
        if($res){
            header("Location: ../index.php?mess=success");
        }
        else{
            header("Location: ../index.php?mess=error2");
        }
        // Close the database connection
        $conn = null;
        exit();
    }
}
else{
    // If the form data is incomplete or user is not logged in, redirect to the index.php page with an error message
    header("Location: ../index.php?mess=error3");
    exit();
}
?>
