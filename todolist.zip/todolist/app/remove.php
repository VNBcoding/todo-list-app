<?php

// Check if the 'id' parameter is present in the POST request
if(isset($_POST['id'])){
    // Include the database connection file
    require '../db_conn.php';

    // Retrieve the value of the 'id' parameter from the POST request
    $id = $_POST['id'];

    // Check if the 'id' parameter is empty
    if(empty($id)){
        // If 'id' is empty, echo '0' to indicate deletion failure
        echo 0;
    } else {
        // Prepare an SQL statement to delete a row from the 'todo' table where 'id' matches the provided 'id'
        $stmt = $conn->prepare("DELETE FROM todo WHERE id=?");
        // Execute the prepared statement with the value of 'id'
        $res = $stmt->execute([$id]);

        // Check if the execution of the SQL statement was successful
        if($res){
            // If successful, echo '1' to indicate deletion success
            echo 1;
        } else {
            // If unsuccessful, echo '0' to indicate deletion failure
            echo 0;
        }

        // Close the database connection
        $conn = null;
        // Exit the script to prevent further code execution
        exit();
    }
} else {
    // If the 'id' parameter is not present in the POST request, redirect the user to an error page
    header("Location: ../index.php?mess=error");
}
?>
