<?php

if(isset($_POST['id'])){
    require '../db_conn.php';

    $id = $_POST['id'];

    if(empty($id)){
       echo 'error';
    } else {
        $todo = $conn->prepare("SELECT id, checked FROM todo WHERE id=?");
        $todo->execute([$id]);

        $row = $todo->fetch();
        $uId = $row['id'];
        $checked = $row['checked']; 

        // Toggle the checked status
        $uChecked = $checked ? 0 : 1;

        // Use prepared statement for the UPDATE query
        $stmt = $conn->prepare("UPDATE todo SET checked=? WHERE id=?");
        $res = $stmt->execute([$uChecked, $uId]);

        if($res){
            echo $checked; // Return the original checked status
        } else {
            echo "error";
        }
        $conn = null;
        exit();
    }
} else {
    header("Location: ../index.php?mess=error");
}
?>
