<?php
    require 'db_conn.php'; // Include database connection script

    // Check if the user is logged in
    session_start();
    if (!isset($_SESSION['user_id'])) {
        // Redirect the user to the login page if they are not logged in
        header("Location: login.php");
        exit();
    }

    // Fetch the user's to-do list based on their user ID
    $userId = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT * FROM todo WHERE user_id = ? ORDER BY priority1 DESC, id DESC");
    $stmt->execute([$userId]);
    $todo = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* CSS styles for the log out link */
        .logout-link {
            color: blue; 
            text-decoration: none; /* Remove default underline */
            font-weight: bold; /* Make the text bold */
            transition: color 0.3s; /* Add smooth color transition on hover */
        }

        .logout-link:hover {
            color: #0056b3; /* Change link color on hover */
        }

        /* CSS styles for the header */
        .header {
            text-align: center; 
            background-image: 
            padding:  20px; 
            color: transparent;
            -webkit-background-clip: text;
        }

        .header h1 {
            color: #333; 
            font-size: 24px; 
            margin: 0; 
            
            font-family: 'Pacifico', cursive;
            
            font-size: 55px;
           
        }
    </style>
</head>
<body>
<header class="header">
        <h1>Welcome to Todolist</h1>
    </header>
<p><a href="login.php" class="logout-link">Log out</a></p>
    
    <div class="main-section">
        <!-- Adding task bar -->
        <div class="add-section">
            <form action="app/add.php" method="POST" autocomplete="off">
                <?php if(isset($_GET['mess']) && $_GET['mess'] == 'error'){ ?>
                    <!-- Display this input field and button if the 'mess' parameter is set to 'error' -->
                    <input type="text" name="title" placeholder="You have to add a task and due date!" style="border-color: red">
                    <input type="date" name="date_time" style="border-color: red">

                    <button type="submit">Add task</button>
                <?php } else { ?>
                    <!-- Display this input field and button if the 'mess' parameter is not set to 'error' or if it's not present in the URL -->
                    <input type="text" name="title" placeholder="What do you need to do?" />
                    <input type="date" name="date_time">
                    <button type="submit">Add</button>
                <?php } ?>
            </form>
        </div>

        <div class="show-todo-section">
            <?php if(empty($todo)){ ?>
                <div class="row-item">
                    <div class="empty">
                        <img src="img/f1.png" width="100%" />
                        <img src="img/Ellipsis.gif" width="80px">
                    </div>
                </div>
            <?php } else { ?>
                <!-- Loop through the user's to-do list items -->
                <?php foreach($todo as $row) { ?>
                    <div class="todo-item">
                        <span id="<?php echo $row['id']; ?>" class="remove-to-do">x</span>
                        <?php if($row['checked']){ ?> 
                            <?php if($row['priority1']){ ?> 
                                <input type="checkbox" class="check-box" data-todo-id="<?php echo $row['id']; ?>" checked />
                                <h2 class="checked priority"><?php echo $row['title'] ?></h2>
                                <input type="checkbox" priority_id="<?php echo $row['id']; ?>" class="priority-checkbox" checked>
                            <?php } else { ?>
                                <input type="checkbox" class="check-box" data-todo-id="<?php echo $row['id']; ?>" checked />
                                <h2 class="checked"><?php echo $row['title'] ?></h2>
                                <input type="checkbox" priority_id="<?php echo $row['id']; ?>" class="priority-checkbox">
                            <?php } ?>
                        <?php } else { ?>
                            <?php if($row['priority1']){ ?> 
                                <input type="checkbox" class="check-box" data-todo-id="<?php echo $row['id']; ?>" />
                                <h2 class="priority"><?php echo $row['title'] ?></h2>
                                <input type="checkbox" priority_id="<?php echo $row['id']; ?>" class="priority-checkbox" checked>
                            <?php } else { ?>
                                <input type="checkbox" class="check-box" data-todo-id="<?php echo $row['id']; ?>" />
                                <h2><?php echo $row['title'] ?></h2>
                                <input type="checkbox" priority_id="<?php echo $row['id']; ?>" class="priority-checkbox">
                            <?php } ?>
                        <?php } ?>
                        <button class="priority-button">Priority</button>
                        <br>
                        <small>Due date: <?php echo $row['date_time'] ?></small> 
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
    </div>
    <!-- Import jQuery library -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script>
    $(document).ready(function(){
        $('.remove-to-do').click(function(){
            const id = $(this).attr('id');
            $.post("app/remove.php",
            {
                id : id
            },
            (data) => {
                if(data){
                    $(this).parent().hide(600);
                }
            }
            );
        });

        $(".priority-checkbox").click(function(){
            const id = $(this).attr('priority_id');
            $.post('app/priority.php', 
                {
                    id: id,
                },
                (data) => {
                    if(data != 'error'){
                        const h2 = $(this).closest('.todo-item').find('h2');
                        const todoItem = $(this).closest('.todo-item');
                        if(data === '1'){
                             h2.removeClass('priority');
                             todoItem.appendTo('.show-todo-section');
                        } else {
                            h2.addClass('priority');
                            todoItem.prependTo('.show-todo-section');
                        }
                    }
                }
            );
        });

        $(".check-box").click(function(){
            const id = $(this).attr('data-todo-id');
            $.post('app/check.php', 
                {
                    id: id
                },
                (data) => {
                    if(data != 'error'){
                        const h2 = $(this).next();
                        if(data === '1'){
                            h2.removeClass('checked');
                        } else {
                            h2.addClass('checked');
                        }
                    }
                }
            );
        });
    });
    </script>
</body>
</html>
